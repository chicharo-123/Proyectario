var cont =0;
document.getElementById('imageaceptar').onclick = function(){
    confirm('Usted aceptó al oferente "" y ya se le envió una notificación indicando que su registro fue válido');
   
}
document.getElementById('imagerechazar').onclick = function(){
    confirm('Usted rechazó al oferente "" y ya se le envió una notificación indicando que su registro fue rechazado');
}

function esconder(){
    if( $('#datos').is(":visible") ) {
        $('#datos').css('display', 'none'); 
      } else if ( $('#datos').is(":hidden") ){
        $('#datos').css('display', 'block');
      }
}