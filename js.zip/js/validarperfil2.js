const form = document.getElementById('formularioperfil');
const nombreperfil = document.getElementById('nombreperfil');
const areasPerfil = document.getElementById('areasinteresperfil');
const telefonoperfil = document.getElementById('telefonoperfil');
const Correoperfil = document.getElementById('Correoperfil');
const academiaperfil =  document.getElementById('Academiaperfil');

//const rfc_log = document.getElementById('rfc_log');

form.addEventListener("submit", e => {
    e.preventDefault();
    checkInputs();
    console.log("clic");
});

var cont=0;

function checkInputs(){
    //Traer los valores de los inputs
    const nombreperfilv = nombreperfil.value.trim();
    const areasPerfilv = areasPerfil.value.trim();
    const Correoperfilv = Correoperfil.value.trim();
    const telefonoperfilv = telefonoperfil.value.trim();
    const academiaperfilv = academiaperfil.value.trim();
    //const rfc_logv = rfc_log.value.trim();
    //console.log("RFC:", rfc_log);
    cont=0;
    //-----Nombre-------
    if(nombreperfilv ==''){
        cont++;
        //console.log("nombre vacío", nombre);
    setErrorFor(nombreperfil, 'El nombre no puede estar en blanco');
    } else if(!isNombre(nombreperfilv)){
        cont++
        setErrorFor(nombreperfil, 'El nombre no es válido');
    } else{
        cont=cont;
        setSuccessFor(nombreperfil);
    }
    //---areasinteres----
    if(areasPerfilv == ''){
        cont++;
        setErrorFor(areasPerfil, 'No pueden ir vacias tus areas de interés');
    }else{
        cont=cont;
        setSuccessFor(areasPerfil);
    }

    //-----Teléfono------
    if(telefonoperfilv == ''){
        cont++;
        setErrorFor(telefonoperfil, 'El telefono no puede estar en blanco');
    }else if(!isTelefono(telefonoperfilv)){
        cont++;
        setErrorFor(telefonoperfil, 'El teléfono no es válido');
    } else{
        cont=cont;
        setSuccessFor(telefonoperfil); 
    }

    //-----Correo----------
    if(Correoperfilv ==''){
        cont++
        setErrorFor(Correoperfil, 'El correo no puede estar en blanco');
    } else if(!isEmail(Correoperfilv)){
        cont++;
        setErrorFor(Correoperfil, 'El correo no es válido');
    }else{
        cont=cont;
        setSuccessFor(Correoperfil);

    }

    //---Academia------
    if(academiaperfilv == 'Seleccionar academia'){
        cont++;
        setErrorFor(academiaperfil,'seleccione una academia');
    }else{
        cont=cont;
        setSuccessFor(academiaperfil);
    }

    if(cont==0){
           confirm('su perfil se ha guardado con éxito');
    }else{ alert('Hay errores no se guardó el perfil');
         }
   
}

function setErrorFor(input, message) {
    
    const formControl = input.parentElement;
    const small = formControl.querySelector("small");

    small.innerText = message;
    formControl.className = "foorm-control error";

    console.log(formControl);
    console.log(message);
}

function setSuccessFor(input) {
    const formControl = input.parentElement;
    formControl.className = "foorm-control success";
    cont=cont;
  }

function isEmail(correo) {
    return /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/.test(correo);
}
  
function isTelefono(telefono){
    return /^\d{10}$/.test(telefono);
}

function isNombre(nombre){
    return /^[a-zA-ZÁ-ÿ\s]{2,40}$/.test(nombre);
}
