const form = document.getElementById('formularioactividades');
const nombreactividad = document.getElementById('nombreactividad');
const nombreimparte = document.getElementById('nombreimparte');
const enlace = document.getElementById('enlace');


//const rfc_log = document.getElementById('rfc_log');

form.addEventListener("submit", e => {
    e.preventDefault();
    checkInputs();
    console.log("clic");
});

var cont=0;

function checkInputs(){
    //Traer los valores de los inputs
    const nombreactividadv = nombreactividad.value.trim();
    const nombreimpartev = nombreimparte.value.trim();
    const enlacev = enlace.value.trim();
   
    //const rfc_logv = rfc_log.value.trim();
    //console.log("RFC:", rfc_log);
    cont=0;
    //-----Nombre imparte-------
    if(nombreimpartev ==''){
        cont++;
        //console.log("nombre vacío", nombre);
    setErrorFor(nombreimparte, 'El nombre no puede estar en blanco');
    } else if(!isNombre(nombreimpartev)){
        cont++
        setErrorFor(nombreimparte, 'El nombre no es válido');
    } else{
        cont=cont;
        setSuccessFor(nombreimparte);
    }

    //---nombre actividad----
    if(nombreactividadv == ''){
        cont++;
        setErrorFor(nombreactividad, 'No pueden ir vacias tus areas de interés');
    }else{
        cont=cont;
        setSuccessFor(nombreactividad);
    }
    //---- Enlace---------
    if(enlacev == ''){
        cont++;
        setErrorFor(enlace, 'No pueden ir vacias tus areas de interés');
    }else{
        cont=cont;
        setSuccessFor(enlace);
    }

    
    if(cont==0){
 alert('se actualizó la actividad correctamente');
    }else{  
        alert('hay errores, no se actualizó la actividad');

 }
}

function setErrorFor(input, message) {
    
    const formControl = input.parentElement;
    const small = formControl.querySelector("small");

    small.innerText = message;
    formControl.className = "foorm-control error";

    console.log(formControl);
    console.log(message);
}

function setSuccessFor(input) {
    const formControl = input.parentElement;
    formControl.className = "foorm-control success";
    cont=cont;
  }


function isNombre(nombre){
    return /^[a-zA-ZÁ-ÿ\s]{2,40}$/.test(nombre);
}
