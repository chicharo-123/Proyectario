var cont =0;

document.getElementById('imageaceptar').onclick = function(){
  confirm('Usted aceptó al aspirante "" y ya se le envió una notificación indicando que su registro fue válido');
}
document.getElementById('imagerechazar').onclick = function(){
  confirm('Usted rechazó al aspirante "" y ya se le envió una notificación indicando que su registro fue rechazado');
}
 

/*$('#displayNone').click(function(e) {
    // Resetear, por si acaso has estado jugando con la otra propiedad
    $('#hide-me').css('visibility', 'visible');
    
    if( $('#hide-me').is(":visible") ) {
      $('#hide-me').css('display', 'none'); 
    } else {
      $('#hide-me').css('display', 'block');
    }
  });
  */

document.getElementById('displayNone').onclick = function(){
 
  if( $('#datos').is(":visible") ) {
    $('#datos').css('display', 'none'); 
  } else if ( $('#datos').is(":hidden") ){
    $('#datos').css('display', 'block');
  }
  
}
