<?php
    const base_url ="http://localhost/Proyectario_MVC/";//Almacenar la ruta raíz del proyecto
?>