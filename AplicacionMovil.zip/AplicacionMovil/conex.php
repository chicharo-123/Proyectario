
<?php
$server ="localhost";
$username="root";
$password ="";
//$database = "ab3_prueba_proyectario";
$database = "ab_proyectario_prueba";
$conn= new mysqli($server,$username,$password,$database);
if($conn-> connect_error){
die("conection fallied");    
}else{ 
//echo"conectado";
}
?>