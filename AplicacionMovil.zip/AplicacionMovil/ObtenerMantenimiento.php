<?php

require_once "conex.php";

$stmt = $conn->prepare("SELECT habilitado  from configuracion");
$stmt->execute();
$stmt->bind_result($habilitado);
$mantenimiento=array();
while($stmt->fetch()){
    $temp = array();
    $temp['habilitado']= $habilitado;
   
    array_push($mantenimiento, $temp);
}
echo json_encode($mantenimiento);
?>