<?php

require_once "conex.php";
$idCategoria = $_POST['idCategoria'];
$idAlumnos = $_POST['idAlumnos'];
//$idAlumnos='3';
$stmt = $conn->prepare("SELECT proyectos.idCategoria,idSolicitudes, 
solicitudes_proyectos.idProyectos, idAlumnos,idEstados_soli FROM solicitudes_proyectos 
INNER JOIN proyectos on solicitudes_proyectos.idProyectos = proyectos.idProyectos 
WHERE idAlumnos=$idAlumnos AND idEstados_soli=1 and proyectos.idCategoria=$idCategoria
 and proyectos.idCategoria!= 5");
$stmt->execute();
$stmt->bind_result($idCategoria,$idSolicitud,$vacio1,$vacio2,$vacio3);
$solicitud=array();
while($stmt->fetch()){
    $temp = array();
    $temp['proyectos.idCategoria']= $idCategoria;
    array_push($solicitud, $temp);
}
echo json_encode($solicitud);
?>