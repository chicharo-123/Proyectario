<?php

require_once "conex.php";
$Miid = $_POST['Miid'];
//$Miid = '3';
$stmt = $conn->prepare("SELECT idNotificacion, titulo, 
contenido, idCategoria, fecha,notificacion.idProyectos, idActividades_extracurriculares, 
notificacion.idSolicitudes, solicitudes_proyectos.idAlumnos 
from notificacion 
INNER JOIN solicitudes_proyectos on solicitudes_proyectos.idSolicitudes = notificacion.idSolicitudes 
WHERE idAlumnos = $Miid 
ORDER BY fecha");
//SELECT idNotificacion, titulo, contenido, idCategoria, fecha,notificacion.idProyectos idActividades_extracurriculares, notificacion.idSolicitudes, solicitudes_proyectos.idAlumnos from notificacion INNER JOIN solicitudes_proyectos on solicitudes_proyectos.idSolicitudes = notificacion.idSolicitudes WHERE idAlumnos =$Miid

//SELECT idNotificacion, titulo, contenido, idCategoria, fecha,notificacion.idProyectos idActividades_extracurriculares, notificacion.idSolicitudes, solicitudes_proyectos.idAlumnos from notificacion INNER JOIN solicitudes_proyectos on solicitudes_proyectos.idSolicitudes = notificacion.idSolicitudes WHERE idAlumnos =1
$stmt->execute();
$stmt->bind_result($idNotificacion,$titulo,$contenido,$idCategoria,$fecha,$idProyectosNotificacion,
$idActividades_extracurriculares,$idSolicitudesNotificacion,$idAlumnosSolicitudes);
$perfil=array();
while($stmt->fetch()){
    $temp = array();
    $temp['idNotificacion']= $idNotificacion;
    $temp['titulo']= $titulo;
    $temp['contenido']= $contenido;
    $temp['idCategoria']= $idCategoria;
    $temp['fecha']= $fecha;
    $temp['notificacion.idProyectos']= $idProyectosNotificacion;
    $temp['idActividades_extracurriculares']= $idActividades_extracurriculares;
    $temp['notificacion.idSolicitudes']= $idSolicitudesNotificacion;
    $temp['solicitudes_proyectos.idAlumnos']= $idAlumnosSolicitudes;
    array_push($perfil, $temp);
}
echo json_encode($perfil);
?>