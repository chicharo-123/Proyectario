<?php

require_once "conex.php";
$idProyectos = $_POST['idProyecto'];
$idAlumnos = $_POST ['idAlumno'];
//$idProyectos = '5';
//$idAlumnos = '3';
$idEstados_soli= '3';
$motivo= ' ';
echo"idproyecto";
echo $idProyectos;
echo"idAlumno:";
echo $idAlumnos;


//$username = '2018670151';
//$sql2 = "select * from solicitudes_proyectos where idSolicitudes='$idSolicitudes'";
  //    $result = $conn->query($sql2);
    //  if($result -> num_rows > 0){
     // echo"los datos no fueron insertados, ya existe";
     // }else{
      $sql2 = "SELECT * from solicitudes_proyectos WHERE idProyectos = $idProyectos  AND idAlumnos = $idAlumnos";
      $result = $conn->query($sql2);
      if($result -> num_rows > 0){
        echo"los datos no fueron insertados, ya existe";     
      }else{
        $sql = "insert into solicitudes_proyectos values (NULL,'".$idProyectos."','".$idAlumnos."','".$idEstados_soli."','".$motivo."')";
        $result2 = $conn->query($sql);
        echo"datos segun insertados";
      }

      //}

?>
 