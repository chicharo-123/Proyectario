<?php

//consulta para obtener el oferente del proyecto
require_once "conex.php";
$idSolicitud = $_POST['idSolicitud'];
//$idSolicitud ='41';
$stmt = $conn->prepare("SELECT 
 o.nombre as nombre, p.idProyectos as idOProyectosP, p.idOferente as idOferenteP, 
s.idsolicitudes, o.idOferente as idOferenteO, o.nombre 
as oferenteO FROM notificacion n
 INNER JOIN proyectos p ON n.idProyectos = p.idProyectos 
INNER JOIN oferente o ON p.idOferente = o.idOferente 
INNer JOIN solicitudes_proyectos s ON n.idProyectos = s.idProyectos 
WHERE s.idSolicitudes= $idSolicitud");
$stmt->execute();
$stmt->bind_result($nombre,$vacio1,$vacio2,$vacio3,$vacio4,$vacio5);
$alumno=array();
while($stmt->fetch()){
    $temp = array();
    $temp['nombre']= $nombre;
    array_push($alumno, $temp);
}
echo json_encode($alumno);
?>