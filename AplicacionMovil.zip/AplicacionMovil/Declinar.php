<?php

require_once "conex.php";
$idProyectos = $_POST['idProyecto'];
$idAlumnos = $_POST ['idAlumno'];
$idEstados_soli= '3';
$motivo= ' ';
//$username = '2018670151';
//$sql2 = "select * from solicitudes_proyectos where idSolicitudes='$idSolicitudes'";
  //    $result = $conn->query($sql2);
    //  if($result -> num_rows > 0){
     // echo"los datos no fueron insertados, ya existe";
     // }else{

 $sql = "DELETE FROM solicitudes_proyectos WHERE idProyectos = '$idProyectos'  AND idAlumnos = '$idAlumnos'";
 $result = $conn->query($sql);
 if($result){
 echo"datos segun Borrados";
 }else{
    echo"datos no borrados";
 }
      //}

?>