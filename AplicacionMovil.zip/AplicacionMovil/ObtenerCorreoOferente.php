<?php

require_once "conex.php";
$NombreOferente = $_POST['usuarioOferente'];
//$NombreOferente ='Haide Flores';
$stmt = $conn->prepare("SELECT correo from oferente where nombre ='$NombreOferente' ");
$stmt->execute();
$stmt->bind_result($correo);
$oferente=array();
while($stmt->fetch()){
    $temp = array();
    $temp['correo']= $correo;
    array_push( $oferente, $temp);
}
echo json_encode($oferente);
?>