<?php

//consulta para obtener el oferente del proyecto
require_once "conex.php";
$idProyecto = $_POST['idProyecto'];
//$idProyecto = '1';
$stmt = $conn->prepare("SELECT 
o.nombre as nombre, p.idProyectos as idOProyectosP, p.idOferente as idOferenteP, 
o.idOferente as idOferenteO
FROM notificacion n 
INNER JOIN proyectos p ON n.idProyectos = p.idProyectos 
INNER JOIN oferente o ON p.idOferente = o.idOferente
WHERE p.idProyectos= $idProyecto");
$stmt->execute();
$stmt->bind_result($nombre,$vacio1,$vacio2,$vacio3);
$alumno=array();
while($stmt->fetch()){
    $temp = array();
    $temp['nombre']= $nombre;
    array_push($alumno, $temp);
}
echo json_encode($alumno);
?>