<?php

//consulta para obtener el oferente de Actividad
require_once "conex.php";
$idActividad = $_POST['idActividad'];
$stmt = $conn->prepare("SELECT 
 p.nombre_imparte, o.nombre as nombre, p.idActividades_extracurriculares , p.idOferente, 
o.idOferente as idOferenteO,n.idActividades_extracurriculares
FROM notificacion n 
INNER JOIN actividades_extracurriculares p ON n.idActividades_extracurriculares = p.idActividades_extracurriculares 
INNER JOIN oferente o ON p.idOferente = o.idOferente
WHERE p.idActividades_extracurriculares= $idActividad");
$stmt->execute();
$stmt->bind_result($nombre,$vacio1,$vacio2,$vacio3,$vacio4,$vacio5);
$alumno=array();
while($stmt->fetch()){
    $temp = array();
    $temp['p.nombre_imparte']= $nombre;
    array_push($alumno, $temp);
}
echo json_encode($alumno, JSON_UNESCAPED_UNICODE);
?>