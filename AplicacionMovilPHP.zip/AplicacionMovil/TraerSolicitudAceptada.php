<?php

require_once "conex.php";
$idCategoria = $_POST['idCategoria'];
$idAlumnos = $_POST['idAlumnos'];

$stmt = $conn->prepare("SELECT proyectos.idCategoria,idSolicitudes, 
solicitudes_proyectos.idProyectos, idAlumnos,idEstados_soli FROM solicitudes_proyectos 
INNER JOIN proyectos on solicitudes_proyectos.idProyectos = proyectos.idProyectos 
WHERE idAlumnos=$idAlumnos AND idEstados_soli=2 and proyectos.idCategoria=$idCategoria
 and proyectos.idCategoria !=5 ");
$stmt->execute();
$stmt->bind_result($idCategoria,$idSolicitud,$vacio1,$vacio2,$vacio3);
$solicitud=array();
while($stmt->fetch()){
    $temp = array();
    $temp['proyectos.idCategoria']= $idCategoria;
    $temp['idSolicitudes']= $idSolicitud;
    $temp['solicitudes_proyectos.idProyectos']= $vacio1;
    array_push($solicitud, $temp);
}
echo json_encode($solicitud);
?>