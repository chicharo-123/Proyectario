<?php

require_once "conex.php";
//$idSolicitudes= $_POST['idSolicitudes'];
$token = $_POST['token'];
$boleta = $_POST['boleta'];

 $sql = "update alumnos SET token ='$token' WHERE boleta = $boleta";
 //$sql = "insert into alumnos values (NULL,'".$token."','".$idAlumnos."','".$idEstados_soli."','".$motivo."')";
 $result = $conn->query($sql);

 if($result){
 echo"datos segun insertados";
 }else{
    echo"datos no insertados";

 }
      //}

?>