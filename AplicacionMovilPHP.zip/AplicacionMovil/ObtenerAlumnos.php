<?php

require_once "conex.php";
$username = $_POST['boleta'];
//$username = '2018670151';

$stmt = $conn->prepare("SELECT idAlumnos, nombre_al, boleta, idProgramaAcademi, token, carrera from alumnos where boleta=$username");
$stmt->execute();
$stmt->bind_result($idalumno,$nombre_alumno,$boleta_alumno,$idProgramaAcademi,$token,$carrera_alumno);
$alumno=array();
while($stmt->fetch()){
    $temp = array();
    $temp['idAlumnos']= $idalumno;
    $temp['nombre_al']= $nombre_alumno;
    $temp['boleta']= $boleta_alumno;
    $temp['carrera']= $carrera_alumno;
    array_push($alumno, $temp);
}
echo json_encode($alumno);
?>