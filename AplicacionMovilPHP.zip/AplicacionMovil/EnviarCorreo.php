<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

$alumno = $_POST['alumno'];
$mensaje = $_POST['mensaje'];
$correo = $_POST['correo'];
function enviarCorreo(String $correoE, String $mensajeE, String $nombreUsuario){
                        
            $email = $correoE;
           // $estado = $estadoE;
            $mensaje = $mensajeE;
            $resultado = "";
            require 'PHPMailer/Exception.php';
            require 'PHPMailer/PHPMailer.php';
            require 'PHPMailer/SMTP.php';

            //Create an instance; passing `true` enables exceptions
            $mail = new PHPMailer(true);

            try {

                $mail->SMTPOptions = array(
                    'ssl' => array(
                        'verify_peer' => false,
                        'verify_peer_name' => false,
                        'allow_self_signed' => true
                    )
                    );
                //Server settings
                $mail->SMTPDebug = 0;     //SMTP::DEBUG_SERVER                 //Enable verbose debug output 0->No muestra nada, 2->Lista de errores en la depuracion
                $mail->isSMTP();                                            //Send using SMTP Protocolo que se va a usar
                $mail->Host       = 'smtp.gmail.com';                     //Set the SMTP server to send through HOST DEL servidor del correo
                $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
                $mail->Username   = 'proyectarioupiiz@gmail.com';                     //SMTP username
                $mail->Password   = 'proyectarioupiz_EFHC';                               //SMTP password
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            //Enable implicit TLS encryption
                $mail->Port       = 465;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`

                //Recipients
                $mail->setFrom('proyectarioupiiz@gmail.com', 'Proyectario, AVISO');
                $mail->addAddress($email, $nombreUsuario);     //Add a recipient

                //Attachments  ASJUNTAR IMÁGENES O ARCHIVOS
                //$mail->addAttachment('/var/tmp/file.tar.gz');         //Add attachments
                //$mail->addAttachment('/tmp/image.jpg', 'new.jpg');    //Optional name
 
                //Content
                
                $mail->isHTML(true);                                  //Set email format to HTML
                $mail->Subject = 'Proyectario te saluda';
                $mail->Body    = "<!DOCTYPE html>
                        <html lang='es'>
                        <head>
                        <meta charset='UTF-8'>
                        <meta name='viewport' content='width=device-width, initial-scale=1.0'>
                        <title>Mensaje</title>
                        
                        <style>
                                    * {
                                        box-sizing: border-box;
                                    }

                                    body {
                                        margin: 0;
                                        padding: 0;
                                    }

                                    a[x-apple-data-detectors] {
                                        color: inherit !important;
                                        text-decoration: inherit !important;
                                    }

                                    #MessageViewBody a {
                                        color: inherit;
                                        text-decoration: none;
                                    }

                                    p {
                                        line-height: inherit
                                    }

                                    @media (max-width:920px) {
                                        .icons-inner {
                                            text-align: center;
                                        }

                                        .icons-inner td {
                                            margin: 0 auto;
                                        }

                                        .row-content {
                                            width: 100% !important;
                                        }

                                        .image_block img.big {
                                            width: auto !important;
                                        }

                                        .column .border {
                                            display: none;
                                        }

                                        table {
                                            table-layout: fixed !important;
                                        }

                                        .stack .column {
                                            width: 100%;
                                            display: block;
                                        }
                                    }
                                </style>
                        </head>
                        <body>

                        <table border='0' cellpadding='0' cellspacing='0' class='nl-container' role='presentation' style='mso-table-lspace: 0pt; mso-table-rspace: 0pt; background-color: #FFFFFF; background-image: none; background-position: top left; background-size: auto; background-repeat: no-repeat;' width='100%'>
                                        <tbody>
                                            <tr>
                                                <td>
                                                    <table align='center' border='0' cellpadding='0' cellspacing='0' class='row row-1' role='presentation' style='mso-table-lspace: 0pt; mso-table-rspace: 0pt;' width='100%'>
                                                        <tbody>
                                                            <tr>
                                                                <td>
                                                                    <table align='center' border='0' cellpadding='0' cellspacing='0' class='row-content stack' role='presentation' style='mso-table-lspace: 0pt; mso-table-rspace: 0pt; color: #000000; width: 900px;' width='900'>
                                                                        <tbody>
                                                                            <tr>
                                                                                <td class='column column-1' style='mso-table-lspace: 0pt; mso-table-rspace: 0pt; font-weight: 400; text-align: left; vertical-align: top; padding-top: 5px; padding-bottom: 5px; border-top: 0px; border-right: 0px; border-bottom: 0px; border-left: 0px;' width='100%'>
                                                                                    <table border='0' cellpadding='0' cellspacing='0' class='image_block' role='presentation' style='mso-table-lspace: 0pt; mso-table-rspace: 0pt;' width='100%'>
                                                                                        <tr>
                                                                                            <td style='width:100%;padding-right:0px;padding-left:0px;'>
                                                                                                <div align='center' style='line-height:10px'><img class='big' src='http://148.204.142.251/isc/proyectario/Assets/images/Barrad.png' style='display: block; height: auto; border: 0; width: 900px; max-width: 100%;' width='900'/></div>
                                                                                            </td>
                                                                                        </tr>
                                                                                    </table>
                                                                                </td>
                                                                            </tr>
                                                                        </tbody>
                                                                    </table>
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                    <table align='center' border='0' cellpadding='0' cellspacing='0' class='row row-2' role='presentation' style='mso-table-lspace: 0pt; mso-table-rspace: 0pt;' width='100%'>
                                                        <tbody>
                                                            <tr>
                                                                <td>
                                                                    <table align='center' border='0' cellpadding='0' cellspacing='0' class='row-content stack' role='presentation' style='mso-table-lspace: 0pt; mso-table-rspace: 0pt; color: #000000; width: 900px;' width='900'>
                                                                        <tbody>
                                                                            <tr>
                                                                                <td class='column column-1' style='mso-table-lspace: 0pt; mso-table-rspace: 0pt; font-weight: 400; text-align: left; vertical-align: top; border-top: 0px; border-right: 0px; border-bottom: 0px; border-left: 0px;' width='33.333333333333336%'>
                                                                                    <table border='0' cellpadding='0' cellspacing='0' class='image_block' role='presentation' style='mso-table-lspace: 0pt; mso-table-rspace: 0pt;' width='100%'>
                                                                                        <tr>
                                                                                            <td style='width:100%;padding-right:0px;padding-left:0px;padding-top:5px;padding-bottom:5px;'>
                                                                                                <div align='center' style='line-height:10px'><img src='http://148.204.142.251/isc/proyectario/Assets/images/ipn_mch.png' style='display: block; height: auto; border: 0; width: 165px; max-width: 100%;' width='165'/></div>
                                                                                            </td>
                                                                                        </tr>
                                                                                    </table>
                                                                                </td>
                                                                                <td class='column column-2' style='mso-table-lspace: 0pt; mso-table-rspace: 0pt; font-weight: 400; text-align: left; vertical-align: top; border-top: 0px; border-right: 0px; border-bottom: 0px; border-left: 0px;' width='33.333333333333336%'>
                                                                                    <table border='0' cellpadding='0' cellspacing='0' class='heading_block' role='presentation' style='mso-table-lspace: 0pt; mso-table-rspace: 0pt;' width='100%'>
                                                                                        <tr>
                                                                                            <td style='width:100%;text-align:center;padding-top:5px;'>
                                                                                                <h1 style='margin: 0; color: #555555; font-size: 23px; font-family: Arial, Helvetica Neue, Helvetica, sans-serif; line-height: 120%; text-align: center; direction: ltr; font-weight: 700; letter-spacing: normal; margin-top: 0; margin-bottom: 0;'><span class='tinyMce-placeholder'>Instituto Politécnico Nacional</span></h1>
                                                                                            </td>
                                                                                        </tr>
                                                                                    </table>
                                                                                    <table border='0' cellpadding='10' cellspacing='0' class='divider_block' role='presentation' style='mso-table-lspace: 0pt; mso-table-rspace: 0pt;' width='100%'>
                                                                                        <tr>
                                                                                            <td>
                                                                                                <div align='center'>
                                                                                                    <table border='0' cellpadding='0' cellspacing='0' role='presentation' style='mso-table-lspace: 0pt; mso-table-rspace: 0pt;' width='100%'>
                                                                                                        <tr>
                                                                                                            <td class='divider_inner' style='font-size: 1px; line-height: 1px; border-top: 1px solid #BBBBBB;'><span> </span></td>
                                                                                                        </tr>
                                                                                                    </table>
                                                                                                </div>
                                                                                            </td>
                                                                                        </tr>
                                                                                    </table>
                                                                                    <table border='0' cellpadding='0' cellspacing='0' class='paragraph_block' role='presentation' style='mso-table-lspace: 0pt; mso-table-rspace: 0pt; word-break: break-word;' width='100%'>
                                                                                        <tr>
                                                                                            <td style='padding-top:10px;padding-right:10px;padding-bottom:15px;padding-left:10px;'>
                                                                                                <div style='color:#000000;font-size:14px;font-family:Arial, Helvetica Neue, Helvetica, sans-serif;font-weight:400;line-height:120%;text-align:center;direction:ltr;letter-spacing:0px;'>
                                                                                                    <p style='margin: 0;'>Unidad Profesional Interdisciplinaria de Ingeniería campus Zacatecas</p>
                                                                                                </div>
                                                                                            </td>
                                                                                        </tr>
                                                                                    </table>
                                                                                </td>
                                                                                <td class='column column-3' style='mso-table-lspace: 0pt; mso-table-rspace: 0pt; font-weight: 400; text-align: left; vertical-align: top; border-top: 0px; border-right: 0px; border-bottom: 0px; border-left: 0px;' width='33.333333333333336%'>
                                                                                    <table border='0' cellpadding='0' cellspacing='0' class='image_block' role='presentation' style='mso-table-lspace: 0pt; mso-table-rspace: 0pt;' width='100%'>
                                                                                        <tr>
                                                                                            <td style='width:100%;padding-right:0px;padding-left:0px;padding-top:5px;padding-bottom:5px;'>
                                                                                                <div align='center' style='line-height:10px'><img src='http://148.204.142.251/isc/proyectario/Assets/images/upiiz_mch.png' style='display: block; height: auto; border: 0; width: 150px; max-width: 100%;' width='150'/></div>
                                                                                            </td>
                                                                                        </tr>
                                                                                    </table>
                                                                                </td>
                                                                            </tr>
                                                                        </tbody>
                                                                    </table>
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                    <table align='center' border='0' cellpadding='0' cellspacing='0' class='row row-3' role='presentation' style='mso-table-lspace: 0pt; mso-table-rspace: 0pt;' width='100%'>
                                                        <tbody>
                                                            <tr>
                                                                <td>
                                                                    <table align='center' border='0' cellpadding='0' cellspacing='0' class='row-content stack' role='presentation' style='mso-table-lspace: 0pt; mso-table-rspace: 0pt; color: #000000; width: 900px;' width='900'>
                                                                        <tbody>
                                                                            <tr>
                                                                                <td class='column column-1' style='mso-table-lspace: 0pt; mso-table-rspace: 0pt; font-weight: 400; text-align: left; vertical-align: top; padding-top: 5px; padding-bottom: 5px; border-top: 0px; border-right: 0px; border-bottom: 0px; border-left: 0px;' width='100%'>
                                                                                    <table border='0' cellpadding='0' cellspacing='0' class='image_block' role='presentation' style='mso-table-lspace: 0pt; mso-table-rspace: 0pt;' width='100%'>
                                                                                        <tr>
                                                                                            <td style='width:100%;padding-right:0px;padding-left:0px;'>
                                                                                                <div align='center' style='line-height:10px'><img class='big' src='http://148.204.142.251/isc/proyectario/Assets/images/Barrad.png' style='display: block; height: auto; border: 0; width: 900px; max-width: 100%;' width='900'/></div>
                                                                                            </td>
                                                                                        </tr>
                                                                                    </table>
                                                                                </td>
                                                                            </tr>
                                                                        </tbody>
                                                                    </table>
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                    <table align='center' border='0' cellpadding='0' cellspacing='0' class='row row-4' role='presentation' style='mso-table-lspace: 0pt; mso-table-rspace: 0pt;' width='100%'>
                                                        <tbody>
                                                            <tr>
                                                                <td>
                                                                    <table align='center' border='0' cellpadding='0' cellspacing='0' class='row-content stack' role='presentation' style='mso-table-lspace: 0pt; mso-table-rspace: 0pt; color: #000000; width: 900px;' width='900'>
                                                                        <tbody>
                                                                            <tr>
                                                                                <td class='column column-1' style='mso-table-lspace: 0pt; mso-table-rspace: 0pt; font-weight: 400; text-align: left; vertical-align: top; padding-top: 5px; padding-bottom: 5px; border-top: 0px; border-right: 0px; border-bottom: 0px; border-left: 0px;' width='100%'>
                                                                                    <table border='0' cellpadding='0' cellspacing='0' class='image_block' role='presentation' style='mso-table-lspace: 0pt; mso-table-rspace: 0pt;' width='100%'>
                                                                                        <tr>
                                                                                            <td style='width:100%;padding-right:0px;padding-left:0px;'>
                                                                                                <div align='center' style='line-height:10px'><img src='http://148.204.142.251/isc/proyectario/Assets/images/logo_largoch.png' style='display: block; height: auto; border: 0; width: 500px; max-width: 100%;' width='500'/></div>
                                                                                            </td>
                                                                                        </tr>
                                                                                    </table>
                                                                                </td>
                                                                            </tr>
                                                                        </tbody>
                                                                    </table>
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                    <table align='center' border='0' cellpadding='0' cellspacing='0' class='row row-5' role='presentation' style='mso-table-lspace: 0pt; mso-table-rspace: 0pt;' width='100%'>
                                                        <tbody>
                                                            <tr>
                                                                <td>
                                                                    <table align='center' border='0' cellpadding='0' cellspacing='0' class='row-content stack' role='presentation' style='mso-table-lspace: 0pt; mso-table-rspace: 0pt; color: #000000; width: 900px;' width='900'>
                                                                        <tbody>
                                                                            <tr>
                                                                                <td class='column column-1' style='mso-table-lspace: 0pt; mso-table-rspace: 0pt; font-weight: 400; text-align: left; vertical-align: top; padding-top: 5px; padding-bottom: 5px; border-top: 0px; border-right: 0px; border-bottom: 0px; border-left: 0px;' width='100%'>
                                                                                    <table border='0' cellpadding='10' cellspacing='0' class='divider_block' role='presentation' style='mso-table-lspace: 0pt; mso-table-rspace: 0pt;' width='100%'>
                                                                                        <tr>
                                                                                            <td>
                                                                                                <div align='center'>
                                                                                                    <table border='0' cellpadding='0' cellspacing='0' role='presentation' style='mso-table-lspace: 0pt; mso-table-rspace: 0pt;' width='100%'>
                                                                                                        <tr>
                                                                                                            <td class='divider_inner' style='font-size: 1px; line-height: 1px; border-top: 1px solid #BBBBBB;'><span> </span></td>
                                                                                                        </tr>
                                                                                                    </table>
                                                                                                </div>
                                                                                            </td>
                                                                                        </tr>
                                                                                    </table>
                                                                                    <table border='0' cellpadding='0' cellspacing='0' class='heading_block' role='presentation' style='mso-table-lspace: 0pt; mso-table-rspace: 0pt;' width='100%'>
                                                                                        <tr>
                                                                                            <td style='width:100%;text-align:center;'>
                                                                                                <h1 style='margin: 0; color: #555555; font-size: 23px; font-family: Arial, Helvetica Neue, Helvetica, sans-serif; line-height: 120%; text-align: center; direction: ltr; font-weight: 700; letter-spacing: normal; margin-top: 0; margin-bottom: 0;'><span class='tinyMce-placeholder'>Aviso de proyectario: </span></h1>
                                                                                            </td>
                                                                                        </tr>
                                                                                    </table>
                                                                                </td>
                                                                            </tr>
                                                                        </tbody>
                                                                    </table>
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                    <table align='center' border='0' cellpadding='0' cellspacing='0' class='row row-6' role='presentation' style='mso-table-lspace: 0pt; mso-table-rspace: 0pt;' width='100%'>
                                                        <tbody>
                                                            <tr>
                                                                <td>
                                                                    <table align='center' border='0' cellpadding='0' cellspacing='0' class='row-content stack' role='presentation' style='mso-table-lspace: 0pt; mso-table-rspace: 0pt; color: #000000; width: 900px;' width='900'>
                                                                        <tbody>
                                                                            <tr>
                                                                                <td class='column column-1' style='mso-table-lspace: 0pt; mso-table-rspace: 0pt; font-weight: 400; text-align: left; vertical-align: top; padding-top: 5px; padding-bottom: 5px; border-top: 0px; border-right: 0px; border-bottom: 0px; border-left: 0px;' width='100%'>
                                                                                    <table border='0' cellpadding='10' cellspacing='0' class='divider_block' role='presentation' style='mso-table-lspace: 0pt; mso-table-rspace: 0pt;' width='100%'>
                                                                                        <tr>
                                                                                            <td>
                                                                                                <div align='center'>
                                                                                                    <table border='0' cellpadding='0' cellspacing='0' role='presentation' style='mso-table-lspace: 0pt; mso-table-rspace: 0pt;' width='70%'>
                                                                                                        <tr>
                                                                                                            <td class='divider_inner' style='font-size: 1px; line-height: 1px; border-top: 1px solid #B0185A;'><span> </span></td>
                                                                                                        </tr>
                                                                                                    </table>
                                                                                                </div>
                                                                                            </td>
                                                                                        </tr>
                                                                                    </table>
                                                                                    <table border='0' cellpadding='10' cellspacing='0' class='paragraph_block' role='presentation' style='mso-table-lspace: 0pt; mso-table-rspace: 0pt; word-break: break-word;' width='100%'>
                                                                                        <tr>
                                                                                            <td>
                                                                                                <div style='color:#000000;font-size:14px;font-family:Arial, Helvetica Neue, Helvetica, sans-serif;font-weight:400;line-height:120%;text-align:left;direction:ltr;letter-spacing:0px;'>
                                                                                                    <p style='margin: 0;'>$mensaje</p>
                                                                                                </div>
                                                                                            </td>
                                                                                        </tr>
                                                                                    </table>
                                                                                    <table border='0' cellpadding='0' cellspacing='0' class='heading_block' role='presentation' style='mso-table-lspace: 0pt; mso-table-rspace: 0pt;' width='100%'>
                                                                                        <tr>
                                                                                            <td style='width:100%;text-align:center;padding-top:60px;'>
                                                                                                <h1 style='margin: 0; color: #555555; font-size: 23px; font-family: Arial, Helvetica Neue, Helvetica, sans-serif; line-height: 120%; text-align: left; direction: ltr; font-weight: 700; letter-spacing: normal; margin-top: 0; margin-bottom: 0;'><span class='tinyMce-placeholder'>Contáctanos</span></h1>
                                                                                            </td>
                                                                                        </tr>
                                                                                    </table>
                                                                                    <table border='0' cellpadding='10' cellspacing='0' class='list_block' role='presentation' style='mso-table-lspace: 0pt; mso-table-rspace: 0pt; word-break: break-word;' width='100%'>
                                                                                        <tr>
                                                                                            <td>
                                                                                                <ul style='margin: 0; padding: 0; margin-left: 20px; color: #000000; font-size: 14px; font-family: Arial, Helvetica Neue, Helvetica, sans-serif; font-weight: 400; line-height: 120%; text-align: left; direction: ltr; letter-spacing: 0px;'>
                                                                                                    <li>Obtén atención personalizada por medio de nuestro Equipo de Atención por vía telefónica o correo electrónico.</li>
                                                                                                </ul>
                                                                                            </td>
                                                                                        </tr>
                                                                                    </table>
                                                                                </td>
                                                                            </tr>
                                                                        </tbody>
                                                                    </table>
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                    <table align='center' border='0' cellpadding='0' cellspacing='0' class='row row-7' role='presentation' style='mso-table-lspace: 0pt; mso-table-rspace: 0pt;' width='100%'>
                                                        <tbody>
                                                            <tr>
                                                                <td>
                                                                    <table align='center' border='0' cellpadding='0' cellspacing='0' class='row-content stack' role='presentation' style='mso-table-lspace: 0pt; mso-table-rspace: 0pt; color: #000000; width: 900px;' width='900'>
                                                                        <tbody>
                                                                            <tr>
                                                                                <td class='column column-1' style='mso-table-lspace: 0pt; mso-table-rspace: 0pt; font-weight: 400; text-align: left; vertical-align: top; border-top: 0px; border-right: 0px; border-bottom: 0px; border-left: 0px;' width='25%'>
                                                                                    <table border='0' cellpadding='0' cellspacing='0' class='image_block' role='presentation' style='mso-table-lspace: 0pt; mso-table-rspace: 0pt;' width='100%'>
                                                                                        <tr>
                                                                                            <td style='width:100%;padding-right:0px;padding-left:0px;padding-top:5px;padding-bottom:5px;'>
                                                                                                <div align='right' style='line-height:10px'><img src='http://148.204.142.251/isc/proyectario/Assets/images/telefono.png' style='display: block; height: auto; border: 0; width: 68px; max-width: 100%;' width='68'/></div>
                                                                                            </td>
                                                                                        </tr>
                                                                                    </table>
                                                                                </td>
                                                                                <td class='column column-2' style='mso-table-lspace: 0pt; mso-table-rspace: 0pt; font-weight: 400; text-align: left; vertical-align: top; border-top: 0px; border-right: 0px; border-bottom: 0px; border-left: 0px;' width='50%'>
                                                                                    <table border='0' cellpadding='0' cellspacing='0' class='heading_block' role='presentation' style='mso-table-lspace: 0pt; mso-table-rspace: 0pt;' width='100%'>
                                                                                        <tr>
                                                                                            <td style='width:100%;text-align:center;padding-top:10px;'>
                                                                                                <h1 style='margin: 0; color: #000000; font-size: 18px; font-family: Arial, Helvetica Neue, Helvetica, sans-serif; line-height: 120%; text-align: left; direction: ltr; font-weight: 700; letter-spacing: normal; margin-top: 0; margin-bottom: 0;'><span class='tinyMce-placeholder'>Asesor telefónico</span></h1>
                                                                                            </td>
                                                                                        </tr>
                                                                                    </table>
                                                                                    <table border='0' cellpadding='0' cellspacing='0' class='paragraph_block' role='presentation' style='mso-table-lspace: 0pt; mso-table-rspace: 0pt; word-break: break-word;' width='100%'>
                                                                                        <tr>
                                                                                            <td style='padding-right:10px;padding-bottom:15px;padding-left:10px;'>
                                                                                                <div style='color:#000000;font-size:14px;font-family:Arial, Helvetica Neue, Helvetica, sans-serif;font-weight:400;line-height:120%;text-align:left;direction:ltr;letter-spacing:0px;'>
                                                                                                    <p style='margin: 0;'>4589890046</p>
                                                                                                </div>
                                                                                            </td>
                                                                                        </tr>
                                                                                    </table>
                                                                                </td>
                                                                                <td class='column column-3' style='mso-table-lspace: 0pt; mso-table-rspace: 0pt; font-weight: 400; text-align: left; vertical-align: top; border-top: 0px; border-right: 0px; border-bottom: 0px; border-left: 0px;' width='25%'>
                                                                                    <table border='0' cellpadding='0' cellspacing='0' class='empty_block' role='presentation' style='mso-table-lspace: 0pt; mso-table-rspace: 0pt;' width='100%'>
                                                                                        <tr>
                                                                                            <td style='padding-right:0px;padding-bottom:5px;padding-left:0px;padding-top:5px;'>
                                                                                                <div></div>
                                                                                            </td>
                                                                                        </tr>
                                                                                    </table>
                                                                                </td>
                                                                            </tr>
                                                                        </tbody>
                                                                    </table>
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                    <table align='center' border='0' cellpadding='0' cellspacing='0' class='row row-8' role='presentation' style='mso-table-lspace: 0pt; mso-table-rspace: 0pt;' width='100%'>
                                                        <tbody>
                                                            <tr>
                                                                <td>
                                                                    <table align='center' border='0' cellpadding='0' cellspacing='0' class='row-content stack' role='presentation' style='mso-table-lspace: 0pt; mso-table-rspace: 0pt; color: #000000; width: 900px;' width='900'>
                                                                        <tbody>
                                                                            <tr>
                                                                                <td class='column column-1' style='mso-table-lspace: 0pt; mso-table-rspace: 0pt; font-weight: 400; text-align: left; vertical-align: top; border-top: 0px; border-right: 0px; border-bottom: 0px; border-left: 0px;' width='25%'>
                                                                                    <table border='0' cellpadding='0' cellspacing='0' class='image_block' role='presentation' style='mso-table-lspace: 0pt; mso-table-rspace: 0pt;' width='100%'>
                                                                                        <tr>
                                                                                            <td style='width:100%;padding-right:0px;padding-left:0px;padding-top:5px;padding-bottom:5px;'>
                                                                                                <div align='right' style='line-height:10px'><img src='http://148.204.142.251/isc/proyectario/Assets/images/email.png' style='display: block; height: auto; border: 0; width: 68px; max-width: 100%;' width='68'/></div>
                                                                                            </td>
                                                                                        </tr>
                                                                                    </table>
                                                                                </td>
                                                                                <td class='column column-2' style='mso-table-lspace: 0pt; mso-table-rspace: 0pt; font-weight: 400; text-align: left; vertical-align: top; border-top: 0px; border-right: 0px; border-bottom: 0px; border-left: 0px;' width='50%'>
                                                                                    <table border='0' cellpadding='0' cellspacing='0' class='heading_block' role='presentation' style='mso-table-lspace: 0pt; mso-table-rspace: 0pt;' width='100%'>
                                                                                        <tr>
                                                                                            <td style='width:100%;text-align:center;padding-top:10px;'>
                                                                                                <h1 style='margin: 0; color: #000000; font-size: 18px; font-family: Arial, Helvetica Neue, Helvetica, sans-serif; line-height: 120%; text-align: left; direction: ltr; font-weight: 700; letter-spacing: normal; margin-top: 0; margin-bottom: 0;'><span class='tinyMce-placeholder'>Envíanos un correo</span></h1>
                                                                                            </td>
                                                                                        </tr>
                                                                                    </table>
                                                                                    <table border='0' cellpadding='0' cellspacing='0' class='paragraph_block' role='presentation' style='mso-table-lspace: 0pt; mso-table-rspace: 0pt; word-break: break-word;' width='100%'>
                                                                                        <tr>
                                                                                            <td style='padding-right:10px;padding-bottom:15px;padding-left:10px;'>
                                                                                                <div style='color:#000000;font-size:14px;font-family:Arial, Helvetica Neue, Helvetica, sans-serif;font-weight:400;line-height:120%;text-align:left;direction:ltr;letter-spacing:0px;'>
                                                                                                    <p style='margin: 0;'>proyectarioupiiz@gmail.com</p>
                                                                                                </div>
                                                                                            </td>
                                                                                        </tr>
                                                                                    </table>
                                                                                </td>
                                                                                <td class='column column-3' style='mso-table-lspace: 0pt; mso-table-rspace: 0pt; font-weight: 400; text-align: left; vertical-align: top; border-top: 0px; border-right: 0px; border-bottom: 0px; border-left: 0px;' width='25%'>
                                                                                    <table border='0' cellpadding='0' cellspacing='0' class='empty_block' role='presentation' style='mso-table-lspace: 0pt; mso-table-rspace: 0pt;' width='100%'>
                                                                                        <tr>
                                                                                            <td style='padding-right:0px;padding-bottom:5px;padding-left:0px;padding-top:5px;'>
                                                                                                <div></div>
                                                                                            </td>
                                                                                        </tr>
                                                                                    </table>
                                                                                </td>
                                                                            </tr>
                                                                        </tbody>
                                                                    </table>
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                    <table align='center' border='0' cellpadding='0' cellspacing='0' class='row row-9' role='presentation' style='mso-table-lspace: 0pt; mso-table-rspace: 0pt;' width='100%'>
                                                        <tbody>
                                                            <tr>
                                                                <td>
                                                                    <table align='center' border='0' cellpadding='0' cellspacing='0' class='row-content stack' role='presentation' style='mso-table-lspace: 0pt; mso-table-rspace: 0pt; color: #000000; width: 900px;' width='900'>
                                                                        <tbody>
                                                                            <tr>
                                                                                <td class='column column-1' style='mso-table-lspace: 0pt; mso-table-rspace: 0pt; font-weight: 400; text-align: left; vertical-align: top; border-top: 0px; border-right: 0px; border-bottom: 0px; border-left: 0px;' width='25%'>
                                                                                    <table border='0' cellpadding='0' cellspacing='0' class='image_block' role='presentation' style='mso-table-lspace: 0pt; mso-table-rspace: 0pt;' width='100%'>
                                                                                        <tr>
                                                                                            <td style='width:100%;padding-right:0px;padding-left:0px;padding-top:5px;padding-bottom:5px;'>
                                                                                                <div align='right' style='line-height:10px'><img src='http://148.204.142.251/isc/proyectario/Assets/images/web.png' style='display: block; height: auto; border: 0; width: 68px; max-width: 100%;' width='68'/></div>
                                                                                            </td>
                                                                                        </tr>
                                                                                    </table>
                                                                                </td>
                                                                                <td class='column column-2' style='mso-table-lspace: 0pt; mso-table-rspace: 0pt; font-weight: 400; text-align: left; vertical-align: top; border-top: 0px; border-right: 0px; border-bottom: 0px; border-left: 0px;' width='50%'>
                                                                                    <table border='0' cellpadding='0' cellspacing='0' class='heading_block' role='presentation' style='mso-table-lspace: 0pt; mso-table-rspace: 0pt;' width='100%'>
                                                                                        <tr>
                                                                                            <td style='width:100%;text-align:center;padding-top:10px;'>
                                                                                                <h1 style='margin: 0; color: #000000; font-size: 18px; font-family: Arial, Helvetica Neue, Helvetica, sans-serif; line-height: 120%; text-align: left; direction: ltr; font-weight: 700; letter-spacing: normal; margin-top: 0; margin-bottom: 0;'><span class='tinyMce-placeholder'>Visita nuestro sitio web</span></h1>
                                                                                            </td>
                                                                                        </tr>
                                                                                    </table>
                                                                                    <table border='0' cellpadding='0' cellspacing='0' class='paragraph_block' role='presentation' style='mso-table-lspace: 0pt; mso-table-rspace: 0pt; word-break: break-word;' width='100%'>
                                                                                        <tr>
                                                                                            <td style='padding-right:10px;padding-bottom:15px;padding-left:10px;'>
                                                                                                <div style='color:#1492d8;font-size:14px;font-family:Arial, Helvetica Neue, Helvetica, sans-serif;font-weight:400;line-height:120%;text-align:left;direction:ltr;letter-spacing:0px;'>
                                                                                                    <p style='margin: 0;'>http://148.204.142.251/isc/proyectario/</p>
                                                                                                </div>
                                                                                            </td>
                                                                                        </tr>
                                                                                    </table>
                                                                                </td>
                                                                                <td class='column column-3' style='mso-table-lspace: 0pt; mso-table-rspace: 0pt; font-weight: 400; text-align: left; vertical-align: top; border-top: 0px; border-right: 0px; border-bottom: 0px; border-left: 0px;' width='25%'>
                                                                                    <table border='0' cellpadding='0' cellspacing='0' class='empty_block' role='presentation' style='mso-table-lspace: 0pt; mso-table-rspace: 0pt;' width='100%'>
                                                                                        <tr>
                                                                                            <td style='padding-right:0px;padding-bottom:5px;padding-left:0px;padding-top:5px;'>
                                                                                                <div></div>
                                                                                            </td>
                                                                                        </tr>
                                                                                    </table>
                                                                                </td>
                                                                            </tr>
                                                                        </tbody>
                                                                    </table>
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                    <table align='center' border='0' cellpadding='0' cellspacing='0' class='row row-10' role='presentation' style='mso-table-lspace: 0pt; mso-table-rspace: 0pt;' width='100%'>
                                                        <tbody>
                                                            <tr>
                                                                <td>
                                                                    <table align='center' border='0' cellpadding='0' cellspacing='0' class='row-content stack' role='presentation' style='mso-table-lspace: 0pt; mso-table-rspace: 0pt; color: #000000; width: 900px;' width='900'>
                                                                        <tbody>
                                                                            <tr>
                                                                                <td class='column column-1' style='mso-table-lspace: 0pt; mso-table-rspace: 0pt; font-weight: 400; text-align: left; vertical-align: top; padding-top: 5px; padding-bottom: 5px; border-top: 0px; border-right: 0px; border-bottom: 0px; border-left: 0px;' width='100%'>
                                                                                    <table border='0' cellpadding='0' cellspacing='0' class='icons_block' role='presentation' style='mso-table-lspace: 0pt; mso-table-rspace: 0pt;' width='100%'>
                                                                                        <tr>
                                                                                            <td style='vertical-align: middle; color: #9d9d9d; font-family: inherit; font-size: 15px; padding-bottom: 5px; padding-top: 5px; text-align: center;'>
                                                                                                <table cellpadding='0' cellspacing='0' role='presentation' style='mso-table-lspace: 0pt; mso-table-rspace: 0pt;' width='100%'>
                                                                                                    <tr>
                                                                                                        <td style='vertical-align: middle; text-align: center;'>
                                                                                                            <!--[if vml]><table align='left' cellpadding='0' cellspacing='0' role='presentation' style='display:inline-block;padding-left:0px;padding-right:0px;mso-table-lspace: 0pt;mso-table-rspace: 0pt;'><![endif]-->
                                                                                                            <!--[if !vml]><!-->
                                                                                                            <table cellpadding='0' cellspacing='0' class='icons-inner' role='presentation' style='mso-table-lspace: 0pt; mso-table-rspace: 0pt; display: inline-block; margin-right: -4px; padding-left: 0px; padding-right: 0px;'>
                                                                                                            <!--<![endif]-->
                                                                                                                <tr>
                                                                                                                    
                                                                                                                </tr>
                                                                                                            </table>
                                                                                                        </td>
                                                                                                    </tr>
                                                                                                </table>
                                                                                            </td>
                                                                                        </tr>
                                                                                    </table>
                                                                                </td>
                                                                            </tr>
                                                                        </tbody>
                                                                    </table>
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                        
                        </body>
                        </html>";

                $mail->send();
                //echo 'Mensaje enviado';
                $resultado = "enviado";
            } catch (Exception $e) {
                //echo "Mensaje De Error: {$mail->ErrorInfo}";
                $resultado = "error".$mail->ErrorInfo;
            
            }

            return $resultado;
        }

        enviarCorreo( $correo, $mensaje, $alumno);        

        ?>