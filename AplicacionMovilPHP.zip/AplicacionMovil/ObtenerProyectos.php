<?php

require_once "conex.php";

$category1 = $_POST['category1'];
$category2 = $_POST['category2'];
$category3 = $_POST['category3'];
$category4 = $_POST['category4'];
$category5 = $_POST['category5'];
$category6 = $_POST['category6'];
/*
$category1 = '1';
$category2 = '1';
$category3 = '1';
$category4 = '1';
$category5 = '1';
$category6 = '0';
*/

if($category1=="1"){
    $pos1=1;
}else{$pos1=6;}

if($category2=="1"){
 $pos2 =2;
}else{$pos2=6;}

if($category3=="1"){
    $pos3 =3;
}else{$pos3=6;}

if($category4=="1"){
    $pos4 =4;
}else{$pos4=6;}

if($category5=="1"){
    $pos5 =5;
}else{$pos5=6;}

if($category6=="1"){
    $stmt2 = $conn->prepare("SELECT proyectos.idProyectos 
    ,proyectos.titulo, proyectos.idCategoria, creditos_ss,
    proyectos.descripcion,proyectos.requisitos, proyectos.num_alumnos, proyectos.idOferente,
     proyectos.estado_proyecto, oferente.nombre, perfil.idacademia, oferente.correo, 
     especificar_alumnos.programa_academi, especificar_alumnos.num_alumnose,
     especificar_alumnos.idProyectos,
     group_concat(DISTINCT especificar_alumnos.num_alumnose,' ',especificar_alumnos.programa_academi,'\n') as progra,
      oferente.RFC
     from proyectos   
     LEFT JOIN perfil on proyectos.idOferente = perfil.idOferente 
     INNER JOIN especificar_alumnos on proyectos.idProyectos = especificar_alumnos.idProyectos
     Inner JOIN oferente on proyectos.idOferente=oferente.idOferente
 where idCategoria= $pos1 or idCategoria=$pos2 or idCategoria=$pos3 or idCategoria=$pos4 or idCategoria=$pos5 and estado_proyecto = 0
 GROUP BY 1");

$stmt2->execute();
$stmt2->bind_result($idProyectos,$titulo,$idCategoria,$creditos_ss,$descripcion,$requisitos,$num_alumnos,
$idOferente,$estado_proyecto,$nombre_perfil,$idAcademia,$correo,$programaAcademico,$num_almnose,$alumno_idProyecto, $progra,$RFC);
$proyecto=array();

    while($stmt2->fetch()){
    $temp = array();
    $temp['idProyectos']= $idProyectos;
    $temp['titulo']= $titulo;
    $temp['idCategoria']= $idCategoria;
    $temp['creditos_ss']= $creditos_ss;
    $temp['descripcion']= $descripcion;
    $temp['requisitos']= $requisitos;
    $temp['num_alumnos']= $num_alumnos;
    $temp['idOferente']= $idOferente;
    $temp['estado_proyecto']= $estado_proyecto;
    $temp['oferente.nombre']=$nombre_perfil;
    $temp['perfil.idacademia']=$idAcademia;
    $temp['oferente.correo']= $correo;
    $temp['especificar_alumnos.programa_academi']= $programaAcademico;
    $temp['especificar_alumnos.num_alumnose']= $num_almnose;
    $temp['especificar_alumnos.idProyectos']= $alumno_idProyecto;
    $temp['progra']= $progra;
    $temp['oferente.RFC']= $progra;
    array_push($proyecto, $temp);
    }
echo json_encode($proyecto);
}else{
  
$stmt2 = $conn->prepare("SELECT proyectos.idProyectos 
,proyectos.titulo, proyectos.idCategoria, creditos_ss,
proyectos.descripcion,proyectos.requisitos, proyectos.num_alumnos, proyectos.idOferente,
 proyectos.estado_proyecto, oferente.nombre, perfil.idacademia, oferente.correo, 
 especificar_alumnos.programa_academi, especificar_alumnos.num_alumnose,
 especificar_alumnos.idProyectos,
 group_concat(DISTINCT especificar_alumnos.num_alumnose,' ',especificar_alumnos.programa_academi,'\n') as progra, 
 oferente.RFC
 from proyectos   
 LEFT JOIN perfil on proyectos.idOferente = perfil.idOferente 
 INNER JOIN especificar_alumnos on proyectos.idProyectos = especificar_alumnos.idProyectos
 Inner JOIN oferente on proyectos.idOferente=oferente.idOferente
 where idCategoria= $pos1 or idCategoria=$pos2 or idCategoria=$pos3 or idCategoria=$pos4 or idCategoria=$pos5 
 GROUP BY 1");
    $stmt2->execute();
    $stmt2->bind_result($idProyectos,$titulo,$idCategoria,$creditos_ss,
    $descripcion,$requisitos,$num_alumnos,$idOferente,
    $estado_proyecto,$nombre_perfil,$idAcademia,$correo,
    $programaAcademico,$num_almnose,$alumno_idProyecto, $progra,$RFC);

$proyecto=array();

while($stmt2->fetch()){
    $temp = array();
    $temp['idProyectos']= $idProyectos;
    $temp['titulo']= $titulo;
    $temp['idCategoria']= $idCategoria;
    $temp['creditos_ss']= $creditos_ss;
    $temp['descripcion']= $descripcion;
    $temp['requisitos']= $requisitos;
    $temp['num_alumnos']= $num_alumnos;
    $temp['idOferente']= $idOferente;
    $temp['estado_proyecto']= $estado_proyecto;
    $temp['oferente.nombre']=$nombre_perfil;
    $temp['perfil.idacademia']=$idAcademia;
    $temp['oferente.correo']= $correo;
    $temp['especificar_alumnos.programa_academi']= $programaAcademico;
    $temp['especificar_alumnos.num_alumnose']= $num_almnose;
    $temp['especificar_alumnos.idProyectos']= $alumno_idProyecto;
    $temp['progra']= $progra;
    $temp['oferente.RFC']= $RFC;
    
    array_push($proyecto, $temp);
}
echo json_encode($proyecto);
}
?>