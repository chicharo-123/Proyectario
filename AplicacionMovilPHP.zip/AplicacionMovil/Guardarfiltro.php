<?php
require_once "conex.php";
$category1 = $_POST['category1'];
$category2 = $_POST['category2'];
$category3 = $_POST['category3'];
$category4 = $_POST['category4'];
$category5 = $_POST['category5'];
$Miid = $_POST['Miid'];
/*
$category1="1";
$category2="1";
$category3="1";
$category4="1";
$category5="1";
$category6="0";
*/

if($category1=="1"){     $pos1=1;
}else{$pos1=0;}

if($category2=="1"){    $pos2 =1;
}else{$pos2=0;}

if($category3=="1"){    $pos3 =1;
}else{$pos3=0;}

if($category4=="1"){    $pos4 =1;
}else{$pos4=0;}

if($category5=="1"){    $pos5 =1;
}else{$pos5=0;}

$sql2 = "select * from filtro_notificacion where idAlumnos='$Miid'";
$result = $conn->query($sql2);
if($result -> num_rows > 0){

echo"los datos no fueron insertados, ya existe";
$sql = "update filtro_notificacion SET SS= $pos1 , TT =$pos2, PT = $pos3,ET= $pos4,UAE = $pos5 WHERE idAlumnos = $Miid ";
$result2 = $conn->query($sql);
}else{
    
$sql = "insert into filtro_notificacion values (NULL,'".$Miid."','".$pos1."','".$pos2."','".$pos3."','".$pos4."','".$pos5."')";
$result2 = $conn->query($sql);
echo"datos segun insertados";
}