<?php

require_once "conex.php";

$Miid = $_POST['Miid'];
$category1 = $_POST['category1'];
$category2 = $_POST['category2'];
$category3 = $_POST['category3'];
$category4 = $_POST['category4'];
$category5 = $_POST['category5'];
/*
$Miid = '3';
$category1 = '1';
$category2 = '1';
$category3 = '1';
$category4 = '1';
$category5 = '1';
*/
$stmt = $conn->prepare("SELECT idNotificacion, titulo, 
contenido, idCategoria, fecha,notificacion.idProyectos, idActividades_extracurriculares, 
notificacion.idSolicitudes, solicitudes_proyectos.idAlumnos 
from notificacion 
INNER JOIN solicitudes_proyectos on solicitudes_proyectos.idSolicitudes = notificacion.idSolicitudes 
WHERE idAlumnos = $Miid 
ORDER BY fecha");
//SELECT idNotificacion, titulo, contenido, idCategoria, fecha,notificacion.idProyectos idActividades_extracurriculares, notificacion.idSolicitudes, solicitudes_proyectos.idAlumnos from notificacion INNER JOIN solicitudes_proyectos on solicitudes_proyectos.idSolicitudes = notificacion.idSolicitudes WHERE idAlumnos =$Miid

//SELECT idNotificacion, titulo, contenido, idCategoria, fecha,notificacion.idProyectos idActividades_extracurriculares, notificacion.idSolicitudes, solicitudes_proyectos.idAlumnos from notificacion INNER JOIN solicitudes_proyectos on solicitudes_proyectos.idSolicitudes = notificacion.idSolicitudes WHERE idAlumnos =1
$stmt->execute();
$stmt->bind_result($idNotificacion,$titulo,$contenido,$idCategoria,$fecha,$idProyectosNotificacion,
$idActividades_extracurriculares,$idSolicitudesNotificacion,$idAlumnosSolicitudes);
$perfil=array();
while($stmt->fetch()){
    $temp = array();
    $temp['idNotificacion']= $idNotificacion;
    $temp['titulo']= $titulo;
    $temp['contenido']= $contenido;
    $temp['idCategoria']= $idCategoria;
    $temp['fecha']= $fecha;
    $temp['notificacion.idProyectos']= $idProyectosNotificacion;
    $temp['idActividades_extracurriculares']= $idActividades_extracurriculares;
    $temp['notificacion.idSolicitudes']= $idSolicitudesNotificacion;
    $temp['solicitudes_proyectos.idAlumnos']= $idAlumnosSolicitudes;
    array_push($perfil, $temp);
}
// Esto es para obtener los proyectos con el filtro

if($category1=="1"){
    $pos1=1;
}else{$pos1=6;}

if($category2=="1"){
 $pos2 =2;
}else{$pos2=6;}

if($category3=="1"){
    $pos3 =3;
}else{$pos3=6;}

if($category4=="1"){
    $pos4 =4;
}else{$pos4=6;}

if($category5=="1"){
    $pos5 =5;
}else{
    $pos5=6;
}
$stmt = $conn->prepare("SELECT idNotificacion, notificacion.titulo as titulo, contenido, proyectos.idCategoria as idCategoria,
 fecha,notificacion.idProyectos, notificacion.idActividades_extracurriculares as idActividades_extracurriculares ,
  notificacion.idSolicitudes from notificacion 
  INNER JOIN proyectos on proyectos.idProyectos = notificacion.idProyectos 
  where proyectos.idCategoria= $pos1 or proyectos.idCategoria=$pos2 or proyectos.idCategoria=$pos3 or 
  proyectos.idCategoria=$pos4 or proyectos.idCategoria=$pos5 and notificacion.idProyectos!=0 ORDER BY fecha");

$stmt->execute();
$stmt->bind_result($idNotificacion,$titulo,$contenido,$idCategoria,$fecha,$idProyectosNotificacion,
$idActividades_extracurriculares,$idSolicitudesNotificacion);

while($stmt->fetch()){
    $temp = array();
    $temp['idNotificacion']= $idNotificacion;
    $temp['titulo']= $titulo;
    $temp['contenido']= $contenido;
    $temp['idCategoria']= $idCategoria;
    $temp['fecha']= $fecha;
    $temp['notificacion.idProyectos']= $idProyectosNotificacion;
    $temp['idActividades_extracurriculares']= 0;
    $temp['notificacion.idSolicitudes']= 0;
    $temp['solicitudes_proyectos.idAlumnos']= 0;
    array_push($perfil, $temp);
}
// finaliza
$stmt = $conn->prepare("SELECT idNotificacion, titulo, 
contenido, idCategoria, fecha,notificacion.idProyectos, notificacion.idActividades_extracurriculares, 
notificacion.idSolicitudes 
from notificacion 
INNER JOIN actividades_extracurriculares on actividades_extracurriculares.idActividades_extracurriculares = notificacion.idActividades_extracurriculares  
ORDER BY fecha");

$stmt->execute();
$stmt->bind_result($idNotificacion,$titulo,$contenido,$idCategoria,$fecha,$idProyectosNotificacion,
$idActividades_extracurriculares,$idSolicitudesNotificacion);

while($stmt->fetch()){
    $temp = array();
    $temp['idNotificacion']= $idNotificacion;
    $temp['titulo']= $titulo;
    $temp['contenido']= $contenido;
    $temp['idCategoria']= $idCategoria;
    $temp['fecha']= $fecha;
    $temp['notificacion.idProyectos']= $idProyectosNotificacion;
    $temp['idActividades_extracurriculares']= $idActividades_extracurriculares;
    $temp['notificacion.idSolicitudes']= 0;
    $temp['solicitudes_proyectos.idAlumnos']= 0;
    array_push($perfil, $temp);
}
$fecha = array();
foreach ($perfil as $key => $row)
{
    $fecha[$key] = $row['fecha'];
}
array_multisort($fecha, SORT_DESC, $perfil);
echo json_encode($perfil);
?>