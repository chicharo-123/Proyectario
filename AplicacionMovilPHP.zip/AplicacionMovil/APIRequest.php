<?php
    
    //include_once '../check_data/isNewAlumno.php';
    //include_once '../check_data/createNewRegisterAlumno.php';
    function convertStringToJSONData($dataToConvert){
        $dataResult = array();

        foreach($dataToConvert as $dataKey=>$dataValue){
            $dataResult[$dataKey] = $dataValue;
        }

        return $dataResult;
    }


    //--------------------------REQUEST A LA API-----------------------------//
    
    $username = $_POST['boleta'];
    $password = $_POST['pass'];

    //$username = '2018670151';
    //$password = 'Cesar.dp10';
    //datos a enviar
    $datos = array(
        'username' => $username,
        'password' => $password
    );

    $datosJSON = json_encode($datos);//lo convertimos a JSON
    
    $curl = curl_init();//Inicializamos

    //Configuramos las opciones del request
    curl_setopt_array($curl, array(
      CURLOPT_URL => "http://148.204.142.2/pump/web/index.php/login",//url de la API
      CURLOPT_RETURNTRANSFER => true,//Para obtener una respuesta
      CURLOPT_CUSTOMREQUEST => "POST",//Es de tipo post el request
      CURLOPT_POSTFIELDS => $datosJSON,//Los datos a enviar
      CURLOPT_HTTPHEADER => array(//Los Headers para poder conectarnos a la API
        "Content-Type: application/json",
        "Authorization: Bearer proefrain"
      ),
    ));
    
    $respuestaRequest = curl_exec($curl);//Ejecutamos el request
    $respuestaRequestJSON = convertStringToJSONData(json_decode($respuestaRequest));
    

    //Si obtenemos una verificación exitosa, guardamos las cookies
    if($respuestaRequestJSON['estatus'] == "true"){
      //Obtenemos los datos del alumno
      $alumnoDATA = json_decode(json_encode($respuestaRequestJSON['datos']),true);
      //generamos los datos que recibiremos por post
      $nombre1=  $alumnoDATA['Nombre'];
      $boleta1=  $alumnoDATA['boleta'];
      $carrera1= $alumnoDATA['Carrera'];

      $nombre= $_POST[$nombre1];
      $boleta=  $_POST[$boleta1];
      $carrera= $_POST[$carrera1];
      $idProgramaAcademi='0';
      if($carrera1=="ING. EN SISTEMAS COMPUTACIONALES"){
        $idProgramaAcademi='1';
      }else{
      }
      if($carrera1=="ING. MECATRÓNICA"){
        $idProgramaAcademi='2';
      }else{
      }
      if($carrera1=="ING. EN ALIMNENTOS"){
        $idProgramaAcademi='4';
      }else{
      }
      if($carrera1=="ING. AMBIENTAL"){
        $idProgramaAcademi='5';
      }else{
      }
      if($carrera1=="ING. METALURGICA"){
        $idProgramaAcademi='3';
      }else{
      }
      $token= "0";

     //comnsultamos si existen los datos en la base de datos, para si es asi, omitir su registro en ella
     require_once "conex.php";
     $sql2 = "select * from alumnos where boleta='$boleta1'";
      $result = $conn->query($sql2);
      if($result -> num_rows > 0){
      echo"los datos no fueron insertados, ya existe";
      }else{
      $sql = "insert into alumnos values (NULL,'".$nombre1."','".$boleta1."','".$idProgramaAcademi."','".$token."','".$carrera1."')";
      $result2 = $conn->query($sql);

      $ultimoID = mysqli_insert_id($conn);
      $sql3="INSERT into filtro_notificacion values(NULL,'".$ultimoID."',1,1,1,1,1)";
      $result3 = $conn->query($sql3);
      echo"datos segun insertados";
      }
      
      //Si los datos son correctos, verificamos si es la primera vez que entra el alumno
      //$isAlreadyLogged = getDataAlumnoIfExists($alumnoDATA['boleta']);
      
      //Mandamos llamar la funcion para usar las variables de sesión
      session_start();

     /* if($isAlreadyLogged['estatus'] == "false"){

        //En caso de ser falso, creamos el nuevo registro del alumno
        $responseCreateNewAlumno = createRegisterAlumno($alumnoDATA);
        
        if(isset($responseCreateNewAlumno['message'])){
          $respuestaRequestJSON['newRegister'] = "warning";
          $respuestaRequestJSON['newRegisterMessage'] = $responseCreateNewAlumno['message'];
        }
        $respuestaRequestJSON['newRegister'] = "success";
        $_SESSION['token'] = $responseCreateNewAlumno['token'];
      }else{
        $_SESSION['token'] = $isAlreadyLogged['token'];
      }*/ 

      //Guardamos las variables de sesión
      $_SESSION['nombre'] = $alumnoDATA['Nombre'];
      $_SESSION['programa'] = $alumnoDATA['Carrera'];
    } 

    curl_close($curl);//Cerramos

    echo json_encode($respuestaRequestJSON);//Enviamos la respuesta
?>