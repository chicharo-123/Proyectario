<?php
require_once "conex.php";
$Miid = $_POST['Miid'];
//$Miid =3;

$stmt = $conn->prepare("SELECT idAlumnos, SS, TT, PT, ET, UAE from filtro_notificacion where idAlumnos=$Miid");
$stmt->execute();
$stmt->bind_result($idAlumnos, $SS,$TT,$PT,$ET,$UAE);
$filtro=array();
while($stmt->fetch()){
    $temp = array();

    $temp['idAlumnos']= $idAlumnos;
    $temp['SS']= $SS;
    $temp['TT']= $TT;
    $temp['PT']= $PT;
    $temp['ET']= $ET;
    $temp['UAE']= $UAE;
    array_push($filtro, $temp);
}
echo json_encode($filtro);
?>