<?php

require_once "conex.php";
$stmt = $conn->prepare("SELECT idPerfil, nombre_perf, areas_interes, perfil.correo, telefono, idAcademia, foto, perfil.idOferente, oferente.RFC from perfil INNER JOIN oferente on oferente.idOferente = perfil.idOferente;
");
$stmt->execute();
$stmt->bind_result($idPerfil,$nombre_perf,$areas_interes,$correo,$telefono,$idAcademia,$foto,$idOferente,$rfc);
$perfil=array();
while($stmt->fetch()){
    $temp = array();
    $temp['idPerfil']= $idPerfil;
    $temp['nombre_perf']= $nombre_perf;
    $temp['areas_interes']= $areas_interes;
    $temp['perfil.correo']= $correo;
    $temp['telefono']= $telefono;
    $temp['idAcademia']= $idAcademia;
    $temp['foto']= $foto;
    $temp['perfil.idOferente']= $idOferente;
    $temp['oferente.rfc']= $rfc;


    array_push($perfil, $temp);
}
echo json_encode($perfil);
?>