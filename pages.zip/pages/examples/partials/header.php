<header>
    
<span align="center" style="text-align:center;align-content:center; vertical-align:middle; line-height: 3;">PROYECTARIO</span>
	
<hr noshade="noshade" style="border-width:.5;color:#edf2f2; background-color:#edf2f2;"/>

</header>