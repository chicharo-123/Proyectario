<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>actualizar actividades</title>

  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="../../plugins/fontawesome-free/css/all.min.css">
 
  <!-- Theme style -->
  <link rel="stylesheet" href="../../dist/css/adminlte.min.css">
                         
</head>
<body class="hold-transition sidebar-mini">

<div class="wrapper">
   <!-- Navbar -->
   <nav class="main-header navbar navbar-expand navbar-white navbar-light" style="background-image: url('../examples/img/barr5.png'); text-color: #fff;">
    <!-- Left navbar links -->
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" data-widget="pushmenu" style="color:#fff;" href="#" role="button"><i class="fas fa-bars"></i></a>
      </li>
    </ul>
  </nav>
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
  <aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="../../index.php" class="brand-link" style="background-image: url('../examples/img/barr5.png');" >
      <img src="../../dist/img/AdminLTELogo.png" alt="AdminLTE Logo" class="brand-image img-circle elevation-3" style="opacity: .8">
      <span class="brand-text font-weight-light">PROYECTARIO</span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
      <!-- Sidebar user (optional) -->
      <div class="user-panel mt-3 pb-3 mb-3 d-flex">
        <!-- SidebarSearch Form -->
        <div class="form-inline">
          <div class="input-group" data-widget="sidebar-search">
            <input class="form-control form-control-sidebar" type="search" placeholder="Search" aria-label="Search">
            <div class="input-group-append">
              <button class="btn btn-sidebar">
                <i class="fas fa-search fa-fw"></i>
              </button>
            </div>
          </div>
        </div>
      </div>

       <!-- Sidebar Menu -->
       <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
            <li class="nav-header" style="background-color: gray; color:#fff"> MENU</li>
            <br>
            <li class="nav-item">
                <a href="../../index.php" class="nav-link">
                    <i class="nav-icon fas fa-tachometer-alt"></i>
                    <p>
                        Inicio
                    </p>
                </a>
            </li>
            <li class="nav-item">
            <a href="../examples/perfil.php" class="nav-link">
              <i class="nav-icon fas fa-columns"></i>
              <p>
                Perfil
              </p>
            </a>
          </li>
          <li class="nav-item">
            <a href="./Ofertar_proyectos.php" class="nav-link">
                <i class="nav-icon fas fa-table"></i>
                <p>
                  Ofertar proyecto
                </p>
            </a>
          </li>
          <li class="nav-item">
            <a href="./Solicitudes.php" class="nav-link">
                <i class="nav-icon fas fa-table"></i>
                <p>
                  Solicitudes
                </p>
            </a>
          </li>
          <li class="nav-item">
            <a href="../mailbox/chat.php" class="nav-link">
                <i class="nav-icon far fa-envelope"></i>
                <p>
                  Chat
                </p>
            </a>
          </li>
          <li class="nav-item">
            <a href="./Ofertar_actividades.php" class="nav-link active" style="background-color: #8E1F4C;">
                <i class="nav-icon fas fa-table"></i>
                <p>
                  Ofertar actividades
                </p>
            </a>
          </li>
          <li class="nav-item">
            <a href="./Validar_registros.php" class="nav-link">
                <i class="nav-icon fas fa-table"></i>
                <p>
                  Validar registros
                </p>
            </a>
          </li>
          <li class="nav-item">
            <a href="../examples/login.php" class="nav-link">
                <i class="nav-icon fas fa-table"></i>
                <p>
                  Cerrar sesión
                </p>
            </a>
          </li>    
        </ul>
      </nav>
      <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
            <h1 class="m-0" style="text-align: center;">PROYECTARIO</h1>
            <hr size="2px" color="black" /> 
            <br>
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->
                    
    <style>
                                        #contenedor{
                                            display:flex;
                                            flex-direction: row;
                                            flex-wrap: wrap;
                                        }
                                        #contenedor > div{
                                            width 50%
                                        }
                                        input[type="text"], input[type="password"]{
                                         outline: none;
                               padding: 20px;
                                   display: block;
                                  width: 300px;
                                  border-radius: 3px;
                                  border:1px solid #eee;
                                  margin: 20px auto;
                              }
                              input[type="subtmit"]{                              
                                  padding: 10px;
                                  color: #fff;
                                  background: #cb2f00;
                                  width: 320px;
                                  margin:20px auto;
                                  margin-top: 0;
                                  border: 0;
                                  border-radius: 3px;
                                  cursor: pointer;
                              }
                            input[type="subtmit"]:haver{
                                 background-color: #eb5e00;
                            }


#divbotones{
        height: 200px;
        margin: auto ;
        border: 5px solid;
        background-color: #FBD603;
    
}



/* cuadro transparente principal*/
.formulario{
    background: rgba(0,0,0,.2);
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0 0 30px rgba(0,0,0,.568);
    color: white;
    
}

/*secciones o campos*/
.foorm-control {
    margin-bottom: 10px;
    padding-bottom: 20px;
    position: relative;
    background: none;
}

.foorm-control label{
    display: inline-block;
    margin-bottom: 5px;
}
.foorm-control input{
    border:1px solid #f0f0f0;
    background: rgba(0,0,0,.3);
    transition: 0.5s ease-in;
    outline: none;
    box-shadow: none;
}
.foorm-control input::placeholder{
    color: white;
}

.foorm-control input:focus{
    background: none;
    outline: none;
    box-shadow: none;
}

.foorm-control.error input{
    border-color: #ce1e0b;
}

.foorm-control.success input{
    border-color: #079e6cf8;  
}
.foorm-control.error textarea{
    border-color: #ce1e0b;
}

.foorm-control.success textarea{
    border-color: #079e6cf8;  
}

.foorm-control i {
    position: absolute;
    top: 40px;
    right: 10px;
    visibility: hidden;
}

.foorm-control.error i.fa-exclamation-circle {
    color: #ce1e0b;
    visibility: visible;
}

.foorm-control small {
    position: absolute;
    visibility: visible;
    float: left; 
    padding: 1em;  
    text-align:left;
    visibility: hidden;
}

.foorm-control.error small{
    color: #ce1e0b;
    /*background-color: none;*/
    visibility: visible;
}
.foorm-control p {
    position: absolute;
    top: 115px;
    visibility: visible;
    float: left; 
    padding: 400px;  
    text-align:left;
    visibility: hidden;
}

.foorm-control.error p{
    color: #ce1e0b;
    /*background-color: none;*/
    visibility: visible;
}
              
                                                         </style>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card">
             
            
              <!-- /.card-header -->
              <div class="card-body">
                      

              <form method="POST" action="#" class="Foorm-control" style="margin:20 px ;"  id="formularioactividades">
                    <div class="formulario" style=" height:750px;">
                        
                    <h2 class="title">Agregar actividad extracurricular</h2>       
                     <br>
                                <!-- Nombre -->

                                    <div class="foorm-control">
                                    <h3> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Nombre: </h3>
                                    </div>
                                    <div class="foorm-control"> 
                                        <input type="text" id="nombreactividad" name="nombreactividad" class="foorm-control" style="width:1070px; transform: translate(-110px, 0px);  padding: 8px10px 50px 20px; " placeholder="Ingresa el nombre de la actividad">                                   
                                        <small id="small">Error: </small>
                                    </div>
                                    <br>
                                 <!-- Nombre de quien imparte-->
                                 
                                 <div class="foorm-control"> 
                                 <h3> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Nombre de la persona que lo imparte: </h3>
                                 </div>
                                    <div class="foorm-control"> 
                                        <input type="text" id="nombreimparte" name="nombreimparte" class="foorm-control" style="width:1070px; transform: translate(-110px, 0px);   padding: 8px10px 50px 20px;" placeholder="Ingresa el nombre de la persona que la imparte">                                   
                                        <small id="small">Error: </small>
                                    </div>
                                    <br>

                                <!-- Enlace-->
                                <div class="foorm-control">
                                <h3> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Enlace: </h3>
                                </div>

                                <div class="foorm-control"> 
                                        <input type="text" id="enlace" name="enlace" class="foorm-control" style="width:1070px; transform: translate(-110px, 0px);  padding: 8px10px 50px 20px; " placeholder="Ingresa el enlace">                                   
                                        <small id="small">Error: </small>
                                    </div>
                                    <button id="agregar" type="submit" style="margin-left: 45%; transform: translate(390px, 30px); width: 150px; height: 50px; background-color:gray; color:white" name="agregar"   class="btn btn-primary" value="Registrar"> Agregar</button>
              </form>
                                </div>
              </div>
              <!-- /.card-body -->
              <div class="card-body">
              <button id="cancelar" style="margin-left: 85%; transform: translate(40px, -25px); width: 150px; height: 50px; background-color:gray; color:white" name="cancelar" onclick="location.href='./ofertar_actividades.php'"  class="btn btn-primary" value="Registrar"> Regresar</button>

                        <br><br>    
    
              </div>
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <footer class="main-footer">
    <div class="float-right d-none d-sm-block">
      <b>Version</b> 3.1.0
    </div>
    <strong>Copyright &copy; 2014-2021 <a href="https://adminlte.io">AdminLTE.io</a>.</strong> All rights reserved.
  </footer>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<!-- jQuery -->
<script src="../../plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="../../plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- DataTables  & Plugins -->
<script src="../../plugins/datatables/jquery.dataTables.min.js"></script>
<script src="../../plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="../../plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
<script src="../../plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
<script src="../../plugins/datatables-buttons/js/dataTables.buttons.min.js"></script>
<script src="../../plugins/datatables-buttons/js/buttons.bootstrap4.min.js"></script>
<script src="../../plugins/jszip/jszip.min.js"></script>
<script src="../../plugins/pdfmake/pdfmake.min.js"></script>
<script src="../../plugins/pdfmake/vfs_fonts.js"></script>
<script src="../../plugins/datatables-buttons/js/buttons.html5.min.js"></script>
<script src="../../plugins/datatables-buttons/js/buttons.print.min.js"></script>
<script src="../../plugins/datatables-buttons/js/buttons.colVis.min.js"></script>
<!-- AdminLTE App -->
<script src="../../dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="../../dist/js/demo.js"></script>
<!-- scripts propios -->
<script src="../../js/validar_actividades_agregar.js"></script>

<!-- Page specific script -->
<script>
  $(function () {
    $("#example1").DataTable({
      "responsive": true, "lengthChange": false, "autoWidth": false,
      "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"]
    }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
    $('#example2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
      "responsive": true,
    });
  });
</script>
</body>
</html>
